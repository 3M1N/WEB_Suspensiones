<?php
//Aqui se establecen las llaves publica y privada del captcha
$publica="6Lc9Zs8SAAAAAPQsWORPigvcSk6LoYOTQiyRfwcV";
$privada="6Lc9Zs8SAAAAAGx1v6NAyNLHJlDpu37ZFv69TJCC";
?>
