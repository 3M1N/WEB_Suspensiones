<div id="wrap">
<div id="header">
<h1><a class="brand" href="<?php echo Site::url(); ?>"><?php echo Site::name(); ?></a></h1>
<div id="nav">
<ul>
<?php echo Menu::get(); ?>
</ul>
</div>
</div>