<h2><?php echo __('New page'); ?></h2>
<br />

<?php if (Notification::get('success')) Alert::success(Notification::get('success')); ?>
<?php if (isset($errors['pages_empty_name']) or isset($errors['pages_exists'])) $error_class1 = 'error'; else $error_class1 = ''; ?>
<?php if (isset($errors['pages_empty_title'])) $error_class2 = 'error'; else $error_class2 = ''; ?>


<?php    
    echo (
        Form::open(null, array('class' => 'form-horizontal'))
    );
?>

<div class="control-group <?php echo $error_class1; ?>">
    <?php
        echo (
            Form::label('page_name', __('Name (slug)'), array('class' => 'control-label'))
        );
    ?>
    <div class="controls">
    <?php
        echo (        
            Form::input('page_name', $post_name, array('class' => 'span6'))
        );

        if (isset($errors['pages_empty_name'])) echo Html::nbsp(3).'<span style="color:red">'.$errors['pages_empty_name'].'</span>';
        if (isset($errors['pages_exists'])) echo Html::nbsp(3).'<span style="color:red">'.$errors['pages_exists'].'</span>';
    ?>
    </div>
</div>

<div class="control-group <?php echo $error_class2; ?>">
    <?php
        echo (
            Html::br().
            Form::label('page_title', __('Title'), array('class' => 'control-label'))
        );
    ?>

    <div class="controls">
    <?php   
        echo (
            Form::input('page_title', $post_title, array('class' => 'span6'))
        );
        if (isset($errors['pages_empty_title'])) echo Html::nbsp(3).'<span style="color:red">'.$errors['pages_empty_title'].'</span>';
    ?>
    </div>
</div>

<?php
    echo (
        Html::br().
        Form::label('page_description', __('Description')).
        Form::input('page_description', $post_description, array('class' => 'span8')).
        Html::br(2).
        Form::label('page_keywords', __('Keywords')).
        Form::input('page_keywords', $post_keywords, array('class' => 'span8'))
    );
?>

<br /><br />
    

<?php Action::run('admin_editor', array(Html::toText($post_content))); ?>

<br />

<div class="row">
    <div class="span3">
    <?php 
        echo (
            Form::label('pages', __('Parent')).
            Form::select('pages', $pages_array, $parent_page) 
        );
    ?>
    </div>    
    <div class="span3">
    <?php
        echo (
            Form::label('templates', __('Template')).
            Form::select('templates', $templates_array, $post_template)
        ); 
    ?>
    </div>
    <div class="span3">
    <?php 
        echo (
            Form::label('status', __('Status')).
            Form::select('status', $status_array, 'published') 
        );
    ?>
    </div>

</div>
<hr>
<div class="row">
    <div class="span6">
        <?php
            echo (
                Form::label('Published on', __('Published on')).
                Form::input('year', $date[0], array('class' => 'span1')). ' ' .
                Form::input('month', $date[1], array('class' => 'span1')). ' ' . 
                Form::input('day', $date[2], array('class' => 'span1')). ' <span style="color:gray;">@</span> '.     
                Form::input('minute', $date[3], array('class' => 'span1')). ' : '.
                Form::input('second', $date[4], array('class' => 'span1'))
            );
        ?>
    </div>
    <div class="span3">
    <?php 
        echo (     
            Form::label('robots', __('Search Engines Robots')).   
            'no Index'.Html::nbsp().Form::checkbox('robots_index', 'index', $post_robots_index).Html::nbsp(2).
            'no Follow'.Html::nbsp().Form::checkbox('robots_follow', 'follow', $post_robots_follow)
        );
    ?>
    </div>
</div>
<hr>
<?php
    echo (
        Form::submit('add_page_and_exit', __('Save and exit'), array('class' => 'btn')).Html::nbsp(2).
        Form::submit('add_page', __('Save'), array('class' => 'btn')).    
        Form::close()
    );
?>