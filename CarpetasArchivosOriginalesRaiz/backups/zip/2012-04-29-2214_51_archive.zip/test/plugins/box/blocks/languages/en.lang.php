<?php

    return array(
        'Blocks' => 'Blocks',
        'Blocks manager' => 'Blocks manager',  
        'delete' => 'delete',
        'edit' => 'edit',
        'Name' => 'Name',
        'Create new block' => 'Create new block',
        'New block' => 'New block',
        'Edit block' => 'Edit block',        
        'Save' => 'Save',        
        'Save and exit' => 'Save and exit',        
        'This field should not be empty' => 'This field should not be empty',
        'This block already exists' => 'This block already exists',
        'This block does not exist' => 'This block does not exist',
        'Delete block: :block' => 'Delete block: :block',
        'Block content' => 'Block content',
        'Block <i>:name</i> deleted' => 'Block <i>:name</i> deleted',
        'Your changes to the block <i>:name</i> have been saved.' => 'Your changes to the block <i>:name</i> have been saved.',
        'Delete block: :block' => 'Delete block: :block',
    );