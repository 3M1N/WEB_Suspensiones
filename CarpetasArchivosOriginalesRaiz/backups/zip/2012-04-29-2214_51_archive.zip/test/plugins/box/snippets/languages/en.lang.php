<?php

    return array(
        'Snippets' => 'Snippets',
        'Snippets manager' => 'Snippets manager',  
        'delete' => 'delete',
        'edit' => 'edit',
        'Name' => 'Name',
        'Create new snippet' => 'Create new snippet',
        'New snippet' => 'New snippet',
        'Edit snippet' => 'Edit snippet',        
        'Save' => 'Save',        
        'Save and exit' => 'Save and exit',        
        'This field should not be empty' => 'This field should not be empty',
        'This snippet already exists' => 'This snippet already exists',
        'This snippet does not exist' => 'This snippet does not exist',
        'Delete snippet: :snippet' => 'Delete snippet: :snippet',
        'Snippet content' => 'Snippet content',
        'Snippet <i>:name</i> deleted' => 'Snippet <i>:name</i> deleted',
        'Your changes to the snippet <i>:name</i> have been saved.' => 'Your changes to the snippet <i>:name</i> have been saved.',
        'Delete snippet: :snippet' => 'Delete snippet: :snippet',
    );