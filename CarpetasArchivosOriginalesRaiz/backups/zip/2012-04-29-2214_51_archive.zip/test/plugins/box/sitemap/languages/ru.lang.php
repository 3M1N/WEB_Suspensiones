<?php
    
    return array(
        'Sitemap' => 'Карта сайта',
    );