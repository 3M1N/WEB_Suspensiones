<h3><?php echo __('Sitemap'); ?></h3>
<br />
<ul>
<?php 

    // Display pages
    if (count($pages_list) > 0)  {    
    	foreach ($pages_list as $page) {		
    		if (trim($page['parent']) !== '') $parent = $page['parent'].'/'; else $parent = '';
    		if (trim($page['parent']) !== '') { echo '<ul>'; }
    		echo '<li><a href="'.Option::get('siteurl').$parent.$page['slug'].'" target="_blank">'.$page['title'].'</a></li>';
    		if (trim($page['parent']) !== '') { echo '</ul>'; }
    	}
        echo '</ul>';
    }

    // Display components
    if (count($components) > 0)  {
        echo '<ul>';
        foreach ($components as $component) {
            echo '<li><a href="'.Option::get('siteurl').Text::lowercase($component).'" target="_blank">'.__($component).'</a></li>';
        }
        echo '</ul>';
    }
?>
</ul>