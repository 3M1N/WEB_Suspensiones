<?php
    
    return array(
        'Sitemap' => 'Sitemap',
    );