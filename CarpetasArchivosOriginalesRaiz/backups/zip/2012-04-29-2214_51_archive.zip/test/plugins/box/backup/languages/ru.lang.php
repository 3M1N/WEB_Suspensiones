<?php

    return array(
        'Backups' => 'Бекапы',
        'Backup date' => 'Бекап',
        'Create backup' => 'Сделать бекап',
        'Delete' => 'Удалить',
        'storage' => 'данные',
        'public' => 'публичная',
        'plugins' => 'плагины',             
        'Delete backup: :backup' => 'Удалить бекап: :backup',
    );