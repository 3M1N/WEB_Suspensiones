<?php

    return array(
		'Backups' => 'Backups',
        'Backup date' => 'Backup date',
		'Create backup' => 'Create backup',
		'Delete' => 'Delete',
        'storage' => 'storage',
        'public' => 'public',
        'plugins' => 'plugins',
        'Delete backup: :backup' => 'Delete backup: :backup',
	);