<!-- Users_edit -->
<?php

    // Show template for exist user else show error
    if ($user !== null) {

    echo ( '<h2>'.__('Edit profile').'</h2>' );

?>

<br />

<?php if (Notification::get('success')) Alert::success(Notification::get('success')); ?>
<?php if (Notification::get('error'))   Alert::error(Notification::get('error')); ?>

<div class="row">

    <div class="span7">    
    <?php

        echo (
            Form::open().
            Form::hidden('user_id', Request::get('user_id'))
        );

        if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], array('admin'))) {        
            echo Form::label('login', __('Login'));
            echo Form::input('login', $user['login'], array('class' => 'span6'));
        } else {
            echo Form::hidden('login', $user['login']);
        }

        echo (
            Html::br().
            Form::label('firstname', __('Firstname')).    
            Form::input('firstname', $user_firstname, array('class' => 'span6')).Html::br().
            Form::label('lastname', __('Lastname')).
            Form::input('lastname', $user_lastname, array('class' => 'span6')).Html::br().
            Form::label('email', __('Email')).
            Form::input('email', $user_email, array('class' => 'span6')).Html::br().
            Form::label('twitter', __('Twitter')).
            Form::input('twitter', $user_twitter, array('class' => 'span6')).Html::br().
            Form::label('skype', __('Skype')).
            Form::input('skype', $user_skype, array('class' => 'span6')).Html::br()
        );

        if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], array('admin'))) {        
            echo Form::label('role', __('Role'));
            echo Form::select('role', array('admin' => __('Admin'),'user' => __('User'),'editor' => __('Editor')), $user['role'], array('class' => 'span3')). Html::br();
        } else {        
            echo Form::hidden('role', $_SESSION['user_role']);
        }


        echo (
            Html::br().
            Form::submit('edit_profile', __('Save'), array('class' => 'btn')).
            Form::close()
        );
      
    ?>
    </div>

    <div class="span7">
    <?php

        echo (
            Form::open().
            Form::hidden('user_id', Request::get('user_id')).
            Form::hidden('real_old_password', $user['password']).
            Form::label('old_password', __('Old password')).
            Form::password('old_password', null, array('class' => 'span6')).Html::br().
            Form::label('new_password', __('New password')).
            Form::password('new_password', null, array('class' => 'span6')).Html::br().Html::br().
            Form::submit('edit_profile_password', __('Save'), array('class' => 'btn')).
            Form::close()
        );    
    ?>
    </div>

</div>

<div style="clear:both"></div>

<?php
    } else {
        echo '<div class="message-error">'.__('This user does not exist').'</div>';
    }
?>
<!-- /Users_edit -->