<!-- Users_add -->
<?php
    echo ( '<h2>'.__('New User Registration').'</h2>' );

    echo (
        Html::br().
        Form::open().
        Form::label('login', __('Login')).
        Form::input('login', null, array('class' => 'span6'))
    );

    if (isset($errors['users_this_user_alredy_exists'])) echo Html::nbsp(3).'<span class="error">'.$errors['users_this_user_alredy_exists'].'</span>';
    if (isset($errors['users_empty_login'])) echo Html::nbsp(3).'<span class="error">'.$errors['users_empty_login'].'</span>';

    echo (
        Form::label('password', __('Password')).
        Form::password('password', null, array('class' => 'span6'))
    );

    if (isset($errors['users_empty_password'])) echo Html::nbsp(3).'<span class="error">'.$errors['users_empty_password'].'</span>';

    echo (
        Form::label('email', __('Email')).
        Form::input('email', null, array('class' => 'span6')). Html::br().
        Form::label('role', __('Role')).
        Form::select('role', array('admin' => __('Admin'), 'user' => __('User'),'editor' => __('Editor')), null, array('class' => 'span3')). Html::br(2).
        Form::submit('register', __('Register'), array('class' => 'btn default')).
        Form::close()
    );
?>
<!-- /Users_add -->