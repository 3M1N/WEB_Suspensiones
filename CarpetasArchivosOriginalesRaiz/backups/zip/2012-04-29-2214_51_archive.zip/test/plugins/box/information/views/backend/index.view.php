<h2><?php echo __('Information'); ?></h2>
<br />

<div class="tabbable">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#system" data-toggle="tab"><?php echo __('System'); ?></a></li>
        <li><a href="#security" data-toggle="tab"><?php echo __('Security'); ?></a></li>        
    </ul>

    <div class="tab-content">
        
        <div class="tab-pane active" id="system">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td><?php echo __('Name'); ?></td>
                        <td><?php echo __('Value'); ?></td>
                    </tr>
                </thead>
                <tbody>
                    <tr>        
                        <td><?php echo __('System version'); ?></td>
                        <td><?php echo MONSTRA_VERSION; ?></td>
                    </tr>
                    <tr>        
                        <td><?php echo __('System version ID'); ?></td>
                        <td><?php echo MONSTRA_VERSION_ID; ?></td>
                    </tr>
                    <tr>        
                        <td><?php echo __('GZIP'); ?></td>
                        <td><?php if (MONSTRA_GZIP) { echo __('on'); } else { echo __('off'); } ?></td>
                    </tr>
                    <tr>        
                        <td><?php echo __('Debuging'); ?></td>
                        <td><?php if (Core::$environment == Core::DEVELOPMENT) { echo __('on'); } else { echo __('off'); } ?></td>
                    </tr>
                </tbody>
            </table>

        </div>
        
        <div class="tab-pane" id="security">

            <?php clearstatcache(); ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td colspan="2"><?php echo __('Security check results'); ?></td>
                    </tr>
                </thead>
                <tbody>
                    <?php if (File::writable(BOOT . DS . 'defines.php')) { ?>
                        <tr> 
                            <td><span class="badge badge-error" style="padding-left:5px; padding-right:5px;"><b>!</b></span> </td>         
                            <td><?php echo __('The configuration file has been found to be writable. We would advise you to remove all write permissions on defines.php on production systems.'); ?></td>
                        </tr>
                    <?php } ?>
                    <?php if (File::writable(MONSTRA . DS)) { ?>
                        <tr>       
                            <td><span class="badge badge-error" style="padding-left:5px; padding-right:5px;"><b>!</b></span> </td>            
                            <td><?php echo __('The Monstra core directory (":path") and/or files underneath it has been found to be writable. We would advise you to remove all write permissions. <br/>You can do this on unix systems with: <code>chmod -R a-w :path</code>', array(':path' => MONSTRA . DS)); ?></td>
                        </tr>
                    <?php } ?>
                    <?php if (File::writable(ROOT . DS . '.htaccess')) { ?>
                        <tr>    
                            <td><span class="badge badge-error" style="padding-left:5px; padding-right:5px;"><b>!</b></span> </td>               
                            <td><?php echo __('The Monstra .htaccess file has been found to be writable. We would advise you to remove all write permissions. <br/>You can do this on unix systems with: <code>chmod a-w :path</code>', array(':path' => ROOT . DS . '.htaccess')); ?></td>
                        </tr>
                    <?php } ?>
                    <?php if (File::writable(ROOT . DS . 'index.php')) { ?>
                        <tr>     
                            <td><span class="badge badge-error" style="padding-left:5px; padding-right:5px;"><b>!</b></span> </td>              
                            <td><?php echo __('The Monstra index.php file has been found to be writable. We would advise you to remove all write permissions. <br/>You can do this on unix systems with: <code>chmod a-w :path</code>', array(':path' => ROOT . DS . 'index.php')); ?></td>
                        </tr>
                    <?php } ?>  
                    <?php if (Core::$environment == Core::DEVELOPMENT) { ?>
                        <tr>
                            <td><span class="badge badge-warning" style="padding-left:5px; padding-right:5px;"><b>!</b></span> </td>               
                            <td><?php echo __('Due to the type and amount of information an error might give intruders when Core::$environment = Core::DEVELOPMENT, we strongly advise setting Core::PRODUCTION in production systems.'); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        
        </div>

     </div>
</div>