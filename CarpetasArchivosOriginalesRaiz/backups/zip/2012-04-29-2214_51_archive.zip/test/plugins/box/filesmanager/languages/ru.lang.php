<?php

    return array(
        'Files' => 'Файлы',
        'Files manager' => 'Менеджер файлов',  
        'Delete' => 'Удалить',
        'Upload' => 'Загрузить',
        'directory' => 'директория',
        'Delete directory: :dir' => 'Удалить директорию: :dir',
        'Delete file: :file' => 'Удалить файл :file',
        'Extension' => 'Расширение',
        'Size' => 'Размер',
    );