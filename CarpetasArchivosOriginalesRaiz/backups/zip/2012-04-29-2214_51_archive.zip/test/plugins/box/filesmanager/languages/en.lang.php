<?php

    return array(
        'Files' => 'Files',
        'Files manager' => 'Files manager',  
        'Delete' => 'Delete',
        'Upload' => 'Upload',
        'directory' => 'directory',
        'Delete directory: :dir' => 'Delete directory: :dir',        
        'Delete file: :file' => 'Delete file :file',
        'Extension' => 'Extension',
        'Size' => 'Size',
    );