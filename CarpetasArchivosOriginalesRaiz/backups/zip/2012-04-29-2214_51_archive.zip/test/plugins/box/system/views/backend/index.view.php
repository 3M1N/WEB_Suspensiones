<!-- System -->

<br />

<?php if (Notification::get('success')) Alert::success(Notification::get('success')); ?>

<?php echo Html::anchor(__('Create sitemap'), 'index.php?id=system&sitemap=create', array('class' => 'btn')).Html::nbsp(2); ?>
<?php echo Html::anchor(__('Delete temporary files'), 'index.php?id=system&temporary_files=delete', array('class' => 'btn')).Html::nbsp(2); ?>
<?php if ('off' == Option::get('maintenance_status')) { ?>
<?php echo Html::anchor(__('Maintenance Mode On'), 'index.php?id=system&maintenance=on', array('class' => 'btn')); ?>
<?php } else { ?>
<?php echo Html::anchor(__('Maintenance Mode Off'), 'index.php?id=system&maintenance=off', array('class' => 'btn btn-danger')); ?>
<?php } ?>
<?php Action::run('admin_system_extra_buttons'); ?>

<hr />

<h2><?php echo __('Site settings'); ?></h2>
<br />
<?php    
    echo (
        Form::open().
        Form::label('site_name', __('Site name')).
        Form::input('site_name', Option::get('sitename'), array('class' => 'span7')). Html::br().
        Form::label('site_description', __('Site description')).
        Form::input('site_description', Option::get('description'), array('class' => 'span7')). Html::br().
        Form::label('site_keywords', __('Site keywords')).
        Form::input('site_keywords', Option::get('keywords'), array('class' => 'span7')). Html::br().
        Form::label('site_slogan', __('Site slogan')).
        Form::input('site_slogan', Option::get('slogan'), array('class' => 'span7')). Html::br().
        Form::label('site_default_page', __('Default page')).
        Form::select('site_default_page', $pages_array, Option::get('defaultpage'), array('class' => 'span3')). Html::br(2)
    );
?>

<h2><?php echo __('System settings'); ?></h2>
<br />
<?php
    echo (
        Form::label('system_url', __('Site url')).
        Form::input('system_url', Option::get('siteurl'), array('class' => 'span7')). Html::br().
        Form::label('system_timezone', __('Time zone')).
        Form::select('system_timezone', Date::timezones(), Option::get('timezone'), array('class' => 'span7')). Html::br().
        Form::label('system_language', __('Language')).
        Form::select('system_language', $languages_array, Option::get('language'), array('class' => 'span2')). Html::br().         
        Form::label('site_maintenance_message', __('Maintenance Mode')).
        Form::textarea('site_maintenance_message', Option::get('maintenance_message'), array('style' => 'width:640px;height:160px;')). Html::br(2)   
    );  
?>

<?php 
    echo (
        Form::submit('edit_settings', __('Save'), array('class' => 'btn')).
        Form::close()
    );
?>
<!-- /System -->