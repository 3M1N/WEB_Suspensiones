<?php


    class SystemAdmin extends Backend {
        
        /**
         * System plugin admin     
         */
        public static function main() {

            if (Session::exists('user_role') && in_array(Session::get('user_role'), array('admin'))) {

                $filters    = Filter::$filters;
                $plugins    = Plugin::$plugins;
                $components = Plugin::$components;        
                $actions    = Action::$actions;

                // Get pages table
                $pages = new Table('pages');

                // Check Monstra version ?
                if (CHECK_MONSTRA_VERSION) {

                    $common_api_url = 'http://monstra.org/api/basic.xml';
                    
                    // Check if is exists common_api_url then try to force load only in system plugin area
                    if (Url::exists($common_api_url) and (isset($_GET['id']) && $_GET['id'] == 'system')) $api_common = XML::loadFile($common_api_url, true);

                    // Check Monstra API
                    // Сheck version
                    if (isset($api_common) && $api_common->MONSTRA_VERSION_ID > MONSTRA_VERSION_ID) {
                        $old_cms_version_message = true;
                    } else {
                        $old_cms_version_message = false;
                    }
                } else {
                    $old_cms_version_message = false;       
                }

                // Get system timezone
                $system_timezone = Option::get('timezone');

                
                // Get languages files
                $language_files = File::scan('../plugins/box/system/languages/', '.lang.php');
                foreach ($language_files as $language) {
                    $parts = explode('.', $language);
                    $l = $parts[0];    
                    $languages_array[$l] = $l;
                }


                // Get all pages
                $pages_array = array();
                $pages_list = $pages->select('[slug!="error404" and parent=""]');
                foreach ($pages_list as $page) {
                    $pages_array[$page['slug']] = $page['title'];
                }


                // Create Sitemap
                // -------------------------------------  
                if (Request::get('sitemap')) {
                    if ('create' == Request::get('sitemap')) {
                        Notification::set('success', __('Sitemap created'));
                        Sitemap::create();
                        Request::redirect('index.php?id=system');
                    }            
                }


                // Delete temporary files
                // -------------------------------------  
                if (Request::get('temporary_files')) {
                    if ('delete' == Request::get('temporary_files')) {

                        $namespaces = Dir::scan(CACHE);
                        if (count($namespaces) > 0) {
                            foreach ($namespaces as $namespace) {
                                Dir::delete(CACHE . DS . $namespace);
                            }
                        }

                        $files = File::scan(MINIFY, array('css','js','php'));                    
                        if (count($files) > 0) {
                            foreach ($files as $file) {
                                File::delete(MINIFY . DS . $file);
                            }               
                        }

                        if (count(File::scan(MINIFY, array('css', 'js', 'php'))) == 0 && count(Dir::scan(CACHE)) == 0) {
                            Notification::set('success', __('Temporary files deleted'));
                            Request::redirect('index.php?id=system');
                        } 
                    }
                }

                // Set maintenance state on or off
                // -------------------------------------  
                if (Request::get('maintenance')) {
                    if ('on' == Request::get('maintenance')) {                            
                        Option::update('maintenance_status', 'on');
                        Request::redirect('index.php?id=system');
                    }
                    if ('off' == Request::get('maintenance')) {                                
                        Option::update('maintenance_status', 'off');
                        Request::redirect('index.php?id=system');
                    }
                }

                // Edit settings
                // -------------------------------------  
                if (Request::post('edit_settings')) {

                    // Add trailing slashes
                    $_site_url = Request::post('system_url');
                    if ($_site_url[strlen($_site_url)-1] !== '/') {
                        $_site_url = $_site_url.'/';
                    }

                    Option::update(array('sitename'          => Request::post('site_name'),
                                       'keywords'            => Request::post('site_keywords'),
                                       'description'         => Request::post('site_description'),
                                       'slogan'              => Request::post('site_slogan'),
                                       'defaultpage'         => Request::post('site_default_page'),
                                       'siteurl'             => $_site_url,
                                       'timezone'            => Request::post('system_timezone'),
                                       'language'            => Request::post('system_language'),
                                       'maintenance_message' => Request::post('site_maintenance_message')));
                    
                    Notification::set('success', __('Your changes have been saved.'));
                    Request::redirect('index.php?id=system');
                }

                // Its mean that you can add your own actions for this plugin
                Action::run('admin_system_extra_actions');

                // Display view
                View::factory('box/system/views/backend/index')
                        ->assign('pages_array', $pages_array)                        
                        ->assign('languages_array', $languages_array)                        
                        ->display();

            } else {

                Request::redirect('index.php?id=users&action=edit&user_id='.Session::get('user_id'));
            } 
        }
    }