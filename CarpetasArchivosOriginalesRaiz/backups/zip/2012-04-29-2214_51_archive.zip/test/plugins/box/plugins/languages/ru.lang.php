<?php
    
    return array(
        'Plugins' => 'Плагины',
        'Installed' => 'Установленные',
        'Install New' => 'Установить новые',
        'Delete' => 'Удалить',
        'Delete plugin :plugin' => 'Удалить плагин :plugin',
        'This plugins does not exist' => 'Такой плагин не существует',
        'Version' => 'Версия',
        'Author' => 'Автор',
        'Get More Plugins' => 'Скачать другие плагины',
    );