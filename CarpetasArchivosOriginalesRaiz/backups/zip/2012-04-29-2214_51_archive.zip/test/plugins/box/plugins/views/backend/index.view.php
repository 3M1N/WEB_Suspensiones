<h2><?php echo __('Plugins'); ?></h2>
<br />


<div class="tabbable">

    <!-- Plugins_tabs -->
    <ul class="nav nav-tabs">
        <li class="active"><a href="#installed" data-toggle="tab"><?php echo __('Installed'); ?> <?php if(count($_users_plugins) > 0) { ?><span class="badge"><?php echo count($_users_plugins); ?></span><?php } ?></a></li>
        <li><a href="#installnew" data-toggle="tab"><?php echo __('Install New'); ?> <?php if(count($plugins_to_intall) > 0) { ?><span class="badge"><?php echo count($plugins_to_intall); ?></span><?php } ?></a></li>
        <li><a href="http://monstra.org" target="_blank"><?php echo __('Get More Plugins'); ?></a></li>
    </ul>
    <!-- /Plugins_tabs -->

    <div class="tab-content">

        <div class="tab-pane active" id="installed">           
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td><?php echo __('Name'); ?></td>
                        <td><?php echo __('Description'); ?></td>
                        <td><?php echo __('Author'); ?></td>
                        <td><?php echo __('Version'); ?></td>
                        <td width="30%"><?php echo __('Actions'); ?></td>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($installed_plugins as $plugin) { if ($plugin['privilege'] !== 'box') { ?>
                    <tr>        
                        <td>
                            <?php echo $plugin['title']; ?>
                        </td>
                        <td>
                           <?php echo $plugin['description']; ?>
                        </td>
                        <td>
                           <a target="_blank" href="<?php echo $plugin['author_uri']; ?>"><?php echo $plugin['author']; ?></a>
                        </td>                        
                        <td>
                            <?php echo $plugin['version']; ?>
                        </td>
                        <td>
                            <?php echo Html::anchor(__('Delete'),
                                       'index.php?id=plugins&delete_plugin='.$plugin['id'],
                                       array('class' => 'btn btn-actions', 'onclick' => "return confirmDelete('".__('Delete plugin :plugin', array(':plugin' => $plugin['id']))."')"));
                             ?>
                        </td>
                    </tr>
                    <?php } } ?>
                </tbody>
            </table>        
        </div>
        

         <div class="tab-pane" id="installnew">       
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td><?php echo __('Name'); ?></td>
                        <td><?php echo __('Description'); ?></td>
                        <td><?php echo __('Author'); ?></td>
                        <td><?php echo __('Version'); ?></td>
                        <td width="30%"><?php echo __('Actions'); ?></td>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php foreach ($plugins_to_intall as $plug) { $plugin_xml = XML::loadFile($plug['path']); ?>
                    <tr>        
                        <td>
                            <?php echo $plugin_xml->plugin_name; ?>
                        </td>
                        <td>
                           <?php echo $plugin_xml->plugin_description; ?>
                        </td>
                        <td>
                           <a href="<?php echo $plugin_xml->plugin_author_uri; ?>"><?php echo $plugin_xml->plugin_author; ?></a>
                        </td>
                        <td>
                            <?php echo $plugin_xml->plugin_version; ?>
                        </td>
                        <td>
                            <?php echo Html::anchor(__('Install'), 'index.php?id=plugins&install='.$plug['plugin'], array('class' => 'btn btn-actions')); ?>
                            <?php echo Html::anchor(__('Delete'),
                                       'index.php?id=plugins&delete_plugin_from_server='.Text::lowercase(basename($plug['path'],'.manifest.xml')),
                                       array('class' => 'btn btn-actions', 'onclick' => "return confirmDelete('".__('Delete plugin :plugin', array(':plugin' =>  Text::lowercase(basename($plug['path'],'.manifest.xml'))) )."')"));
                             ?>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>        
        </div>
        <!-- /Plugins_to_install_list -->

    </div>

</div>