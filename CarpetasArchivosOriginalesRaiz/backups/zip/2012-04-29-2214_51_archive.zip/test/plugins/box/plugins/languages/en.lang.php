<?php
    
    return array(
        'Plugins' => 'Plugins',
        'Installed' => 'Installed',
        'Install New' => 'Install New',
        'Delete' => 'Delete',
        'Delete plugin :plugin' => 'Delete plugin :plugin',
        'This plugins does not exist' => 'This plugins does not exist',
        'Version' => 'Version',
        'Author' => 'Author',
        'Get More Plugins' => 'Get More Plugins',
    );