<?php

    return array(
        'Menu' => 'Меню',        
        'Menu manager' => 'Менеджер меню',
        'Edit' => 'Редактировать',
        'Delete' => 'Удалить',
        'Order' => 'Порядок',
        'Actions' => 'Действия',
        'Create new item' => 'Создать новый пункт меню',
        'New item' => 'Новый пункт меню',
        'Item name' => 'Название',
        'Item order' => 'Порядок',        
        'Item target' => 'Цель',
        'Item link' => 'Ссылка',
        'Save' => 'Сохранить',
        'Edit item' => 'Редактирование пункта меню',
        'Delete item :name' => 'Удалить пункт меню :name',        
        'Add page' => 'Добавить страницу',
        'Select page' => 'Выбрать страницу',
    );