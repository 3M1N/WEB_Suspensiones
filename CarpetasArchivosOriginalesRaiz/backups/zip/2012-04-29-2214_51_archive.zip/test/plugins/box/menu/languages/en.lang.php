<?php

    return array(
        'Menu' => 'Menu',        
        'Menu manager' => 'Menu manager',
        'Edit' => 'Edit',
        'Delete' => 'Delete',
        'Order' => 'Order',
        'Actions' => 'Actions',
        'Create new item' => 'Create new item',
        'New item' => 'New item',
        'Item name' => 'Item name',
        'Item order' => 'Item order',
        'Item target' => 'Item target',
        'Item link' => 'Item link',
        'Save' => 'Save',
        'Edit item' => 'Edit item',
        'Delete item :name' => 'Delete item :name',
        'Add page' => 'Add page',
        'Select page' => 'Select page',
    );