<h2><?php echo __('New item'); ?></h2>
<br />

<?php echo (Form::open()); ?>

<?php if (isset($errors['menu_item_name_empty'])) $error_class = ' error'; else $error_class = ''; ?>

<a href="javascript:;" style="text-decoration:none; color:#333; border-bottom:1px dashed #333;" data-toggle="modal" onclick="$('#addMenuPageModal').width(270).height(500).modal('show');" ><?php echo __('Add page'); ?></a><br /><br />

<?php 

    echo Form::label('menu_item_name', __('Item name'));
    echo Form::input('menu_item_name', $menu_item_name, array('class' => 'span6'.$error_class));

    if (isset($errors['menu_item_name_empty'])) echo Html::nbsp(4).'<span class="error">'.$errors['menu_item_name_empty'].'</span>';

    echo (
        Form::label('menu_item_link', __('Item link')).
        Form::input('menu_item_link', $menu_item_link, array('class' => 'span6'))
    );
?>

<?php
    echo (
        Html::br().
        Form::label('menu_item_target', __('Item target')).
        Form::select('menu_item_target', $menu_item_target_array, $menu_item_target)
    ); 

    echo (
        Html::br().
        Form::label('menu_item_order', __('Item order')).
        Form::select('menu_item_order', $menu_item_order_array, $menu_item_order)
    ); 

    echo (
        Html::br(2).
        Form::submit('menu_add_item', __('Save'), array('class' => 'btn')).        
        Form::close()
    );
?>

<div class="modal" id="addMenuPageModal">
    <div class="modal-header">
        <a class="close" data-dismiss="modal">×</a>
        <h3><?php echo __('Select page'); ?></h3>
    </div>
    <div class="modal-body">
        <p>
        <ul class="unstyled">
        <?php foreach($pages_list as $page) { ?>
            <li><a href="javascript:;" onclick="addMenuPage('<?php echo $page['slug']; ?>', '<?php echo $page['title']; ?>');"><?php echo $page['title']; ?></a></li>
        <?php } ?>
        </ul>
        </p>
    </div>
</div>