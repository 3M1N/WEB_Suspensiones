<?php defined('MONSTRA_ACCESS') or die('No direct script access.');

    // Add New Options
    Option::add('sandbox', 'sandbox test value');
    Option::add('sandbox_template', 'index');